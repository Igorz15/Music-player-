package com.igor.musicplayer

import android.app.*
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class PlaybackService : Service() {
    private var player: MediaPlayer? = null
    private var currentTitle = "Music Player"
    private val channelId = "music_playback"

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Reprodução de música", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> play(intent.data, intent.getStringExtra(EXTRA_TITLE) ?: "Música")
            ACTION_PAUSE -> { player?.pause(); updateNotification("Pausado") }
            ACTION_RESUME -> { player?.start(); updateNotification("Reproduzindo") }
            ACTION_STOP -> { player?.stop(); player?.release(); player = null; stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
        return START_NOT_STICKY
    }

    private fun play(uri: Uri?, title: String) {
        if (uri == null) return
        try {
            player?.release()
            currentTitle = title
            player = MediaPlayer().apply {
                setDataSource(this@PlaybackService, uri)
                setOnPreparedListener { it.start(); updateNotification("Reproduzindo") }
                setOnCompletionListener { updateNotification("Finalizada") }
                setOnErrorListener { _, _, _ -> updateNotification("Erro na reprodução"); true }
                prepareAsync()
            }
            updateNotification("Carregando")
        } catch (_: Exception) { stopSelf() }
    }

    private fun updateNotification(status: String) {
        val openApp = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val pauseIntent = Intent(this, PlaybackService::class.java).setAction(if (status == "Pausado") ACTION_RESUME else ACTION_PAUSE)
        val control = PendingIntent.getService(this, 1, pauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(currentTitle).setContentText(status)
            .setContentIntent(openApp).setOngoing(status == "Reproduzindo" || status == "Carregando")
            .addAction(android.R.drawable.ic_media_pause, if (status == "Pausado") "Continuar" else "Pausar", control)
            .build()
        if (status == "Carregando") startForeground(10, notification) else getSystemService(NotificationManager::class.java).notify(10, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }

    companion object {
        const val ACTION_PLAY = "com.igor.musicplayer.PLAY"
        const val ACTION_PAUSE = "com.igor.musicplayer.PAUSE"
        const val ACTION_RESUME = "com.igor.musicplayer.RESUME"
        const val ACTION_STOP = "com.igor.musicplayer.STOP"
        const val EXTRA_TITLE = "title"
    }
}

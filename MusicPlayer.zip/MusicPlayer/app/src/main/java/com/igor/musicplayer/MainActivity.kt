package com.igor.musicplayer

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val SpotifyGreen = Color(0xFF1DB954)
private val Background = Color(0xFF121212)
private val SurfaceDark = Color(0xFF202020)

class MainActivity : ComponentActivity() {
    private var songs by mutableStateOf<List<Song>>(emptyList())
    private var permissionGranted by mutableStateOf(false)
    private var selectedSong by mutableStateOf<Song?>(null)
    private var playing by mutableStateOf(false)
    private var query by mutableStateOf("")
    private var favoritesOnly by mutableStateOf(false)
    private val favorites = mutableStateListOf<Long>()

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (granted) loadSongs()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        favorites.addAll(getSharedPreferences("music", MODE_PRIVATE).getStringSet("favorites", emptySet())!!.mapNotNull { it.toLongOrNull() })
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        permissionGranted = ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
        if (permissionGranted) loadSongs()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = SpotifyGreen, background = Background, surface = SurfaceDark)) {
                MusicHome(
                    songs = songs, selected = selectedSong, playing = playing, query = query,
                    favorites = favorites.toSet(), favoritesOnly = favoritesOnly,
                    onQuery = { query = it }, onFavoritesOnly = { favoritesOnly = !favoritesOnly },
                    onRequestPermission = { permissionLauncher.launch(permission) },
                    onPlay = { song -> playSong(song) }, onTogglePlayback = { togglePlayback() },
                    onFavorite = { song -> toggleFavorite(song) }, onRescan = { loadSongs() }, onShuffle = { if (songs.isNotEmpty()) playSong(songs.random()) }
                )
            }
        }
    }

    private fun loadSongs() {
        val result = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        try {
            contentResolver.query(collection, projection, selection, null, sort)?.use { cursor: Cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val uri = ContentUris.withAppendedId(collection, id).toString()
                    result.add(Song(id, cursor.getString(titleCol) ?: "Sem título", cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Artista desconhecido", uri, cursor.getLong(durationCol)))
                }
            }
        } catch (_: Exception) { }
        songs = result
    }

    private fun playSong(song: Song) {
        selectedSong = song
        playing = true
        val intent = Intent(this, PlaybackService::class.java).setAction(PlaybackService.ACTION_PLAY)
            .setData(android.net.Uri.parse(song.uri)).putExtra(PlaybackService.EXTRA_TITLE, song.title)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun togglePlayback() {
        val song = selectedSong ?: return
        val action = if (playing) PlaybackService.ACTION_PAUSE else PlaybackService.ACTION_RESUME
        startService(Intent(this, PlaybackService::class.java).setAction(action))
        playing = !playing
    }

    private fun toggleFavorite(song: Song) {
        if (favorites.contains(song.id)) favorites.remove(song.id) else favorites.add(song.id)
        getSharedPreferences("music", MODE_PRIVATE).edit().putStringSet("favorites", favorites.map { it.toString() }.toSet()).apply()
    }
}

@Composable
private fun MusicHome(
    songs: List<Song>, selected: Song?, playing: Boolean, query: String, favorites: Set<Long>, favoritesOnly: Boolean,
    onQuery: (String) -> Unit, onFavoritesOnly: () -> Unit, onRequestPermission: () -> Unit,
    onPlay: (Song) -> Unit, onTogglePlayback: () -> Unit, onFavorite: (Song) -> Unit, onRescan: () -> Unit, onShuffle: () -> Unit
) {
    val visible = songs.filter { (it.title.contains(query, true) || it.artist.contains(query, true)) && (!favoritesOnly || favorites.contains(it.id)) }
    Scaffold(containerColor = Background, bottomBar = {
        Column {
            if (selected != null) MiniPlayer(selected, playing, onTogglePlayback)
            Row(Modifier.fillMaxWidth().background(Color(0xFF080808)).padding(vertical = 10.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.MusicNote, null, tint = SpotifyGreen); Text("Biblioteca", color = Color.White, fontSize = 11.sp) }
                Column(Modifier.clickable(onClick = onFavoritesOnly), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Favorite, null, tint = if (favoritesOnly) SpotifyGreen else Color.LightGray); Text("Favoritas", color = Color.White, fontSize = 11.sp) }
            }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).background(SpotifyGreen, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Color.Black) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Text("MUSIC PLAYER", color = Color.White, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp); Text("Sua música, do seu jeito", color = Color.Gray, fontSize = 11.sp) }
                IconButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, "Tocar música aleatória", tint = SpotifyGreen) }
                IconButton(onClick = onRescan) { Icon(Icons.Default.Refresh, "Atualizar músicas", tint = Color.White) }
            }
            Text("Boa música pra você", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Sua biblioteca offline", color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
            OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Buscar músicas ou artistas", color = Color.Gray) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Color.Gray) }, singleLine = true, shape = RoundedCornerShape(30.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SpotifyGreen, unfocusedBorderColor = Color.DarkGray, focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = SpotifyGreen))
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (favoritesOnly) "Suas favoritas" else "Todas as músicas", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${visible.size} faixas", color = Color.Gray, fontSize = 12.sp)
            }
            if (songs.isEmpty()) {
                Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Default.MusicNote, null, tint = SpotifyGreen, modifier = Modifier.size(58.dp))
                    Text("Sua biblioteca está vazia", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                    Text("Permita o acesso aos arquivos de áudio para encontrar suas músicas.", color = Color.Gray, fontSize = 12.sp)
                    Button(onClick = onRequestPermission, colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen), modifier = Modifier.padding(top = 14.dp)) { Text("Permitir acesso / tentar novamente", color = Color.Black) }
                }
            } else if (visible.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Nenhuma música encontrada.", color = Color.Gray) }
            } else {
                LazyColumn(contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    items(visible, key = { it.id }) { song -> SongRow(song, selected?.id == song.id, favorites.contains(song.id), { onPlay(song) }, { onFavorite(song) }) }
                }
            }
        }
    }
}

@Composable
private fun SongRow(song: Song, selected: Boolean, favorite: Boolean, onPlay: () -> Unit, onFavorite: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onPlay).padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).background(Color(0xFF292929), RoundedCornerShape(7.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = if (selected) SpotifyGreen else Color.LightGray, modifier = Modifier.size(25.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = if (selected) SpotifyGreen else Color.White, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song.artist, color = Color.Gray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favoritar", tint = if (favorite) SpotifyGreen else Color.Gray) }
    }
}

@Composable
private fun MiniPlayer(song: Song, playing: Boolean, onToggle: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF282828)).clickable(onClick = onToggle).padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.MusicNote, null, tint = SpotifyGreen, modifier = Modifier.size(30.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song.artist, color = Color.LightGray, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onToggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pausar" else "Continuar", tint = Color.White, modifier = Modifier.size(30.dp)) }
    }
}

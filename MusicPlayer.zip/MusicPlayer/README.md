# Music Player — Android

Reprodutor local de músicas com interface escura inspirada no Spotify. Não é afiliado ao Spotify e não oferece streaming: reproduz arquivos de áudio disponíveis na biblioteca de mídia do aparelho.

## Recursos
- Busca de músicas por título e artista.
- Leitura da biblioteca de áudio do Android (MediaStore).
- Reprodução e pausa usando o MediaPlayer do Android.
- Serviço de reprodução em primeiro plano para continuar tocando com a tela apagada ou fora do app.
- Notificação com controle de pausar/continuar.
- Favoritos salvos localmente.
- Filtro de favoritas e seleção aleatória de uma faixa.

## Como gerar o APK
1. Instale o **Android Studio** em um computador.
2. Extraia `MusicPlayer.zip`.
3. No Android Studio, escolha **Open** e selecione a pasta `MusicPlayer` (a pasta que contém `settings.gradle.kts`).
4. Aguarde a sincronização do Gradle e a instalação dos componentes do Android SDK, se solicitados.
5. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.
7. Envie o APK para o celular e instale. Se necessário, permita instalação de apps desta origem nas configurações do Android.

## Requisitos do projeto
- Android Studio recente (compatível com Android Gradle Plugin 8.7.3).
- JDK 17.
- Android SDK 35.
- Android 8.0 (API 26) ou superior.

## Observações
- O aplicativo solicita permissão para ler arquivos de áudio. No Android 13 ou superior, usa `READ_MEDIA_AUDIO`.
- As músicas precisam estar na biblioteca de mídia do aparelho; após copiar músicas novas, toque no botão de atualizar.
- Este pacote contém o **projeto-fonte**, não um APK já compilado. A compilação requer Android SDK/Gradle, que não estão disponíveis neste ambiente.
